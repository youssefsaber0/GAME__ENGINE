package XO.model

object XO_state extends Enumeration {

  type tail = Value
  var Empty = Value(0)
  var X = Value(1)
  var O = Value(2)

}
