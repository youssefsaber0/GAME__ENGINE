package XO.model

 class tail {
    var state=XO_state.Empty
}
