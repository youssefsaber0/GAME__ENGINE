package XO.model

object CurrentPlayer {
  var player=Player.player1
}
