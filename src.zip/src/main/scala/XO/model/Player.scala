package XO.model

object Player extends Enumeration{
  type player = Value
  var player1 = Value("O")
  var player2 = Value("X")
}
